import AxiosServices from "./AxiosServices";
import CustomerConfiguration from "../configurations/CustomerConfiguration";

const axiosServices = new AxiosServices();

export default class CustomerServices {
  //AddToCart GetCarts GetOrderHistory OrderItem PaymentGetaway RemoveCart
  AddToCart(data) {
    return axiosServices.post(CustomerConfiguration.AddToCart, data, false);
  }
  GetCarts(data) {
    return axiosServices.post(CustomerConfiguration.GetCarts, data, false);
  }
  GetOrderHistory(data) {
    return axiosServices.post(
      CustomerConfiguration.GetOrderHistory,
      data,
      false
    );
  }
  OrderItem(data) {
    return axiosServices.Patch(CustomerConfiguration.OrderItem, data, false);
  }
  PaymentGetaway(data) {
    return axiosServices.Patch(
      CustomerConfiguration.PaymentGetaway,
      data,
      false
    );
  }
  RemoveCart(data) {
    return axiosServices.Delete(CustomerConfiguration.RemoveCart + data, false);
  }

  CancleOrder(data) {
    return axiosServices.Delete(
      CustomerConfiguration.CancleOrder + data,
      false
    );
  }
}
