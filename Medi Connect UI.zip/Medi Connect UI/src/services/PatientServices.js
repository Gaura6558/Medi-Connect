import AxiosServices from "./AxiosServices";
import PatientConfiguration from "../configurations/PatientConfiguration";

const axiosServices = new AxiosServices();

export default class PatientServices {
  GetAllCityAndSpecializationList() {
    console.log("URL : ", PatientConfiguration.GetAllCityAndSpecializationList);
    return axiosServices.Get(
      PatientConfiguration.GetAllCityAndSpecializationList,
      false
    );
  }

  AddPatient(data) {
    console.log("URL : ", PatientConfiguration.AddPatient);
    return axiosServices.post(PatientConfiguration.AddPatient, data, false);
  }

  GetPatient(data) {
    console.log("URL : ", PatientConfiguration.GetPatient);
    return axiosServices.post(PatientConfiguration.GetPatient, data, false);
  }

  SendFeedback(data) {
    console.log("URL : ", PatientConfiguration.SendFeedback);
    return axiosServices.post(PatientConfiguration.SendFeedback, data, false);
  }
}
