import AxiosServices from "./AxiosServices";
import DoctorConfiguration from "../configurations/DoctorConfiguration";

const axiosServices = new AxiosServices();

export default class DoctorServices {
  GetDoctorList(data) {
    console.log("URL : ", DoctorConfiguration.GetDoctorList);
    return axiosServices.post(DoctorConfiguration.GetDoctorList, data, false);
  }

  ChangePatientStatus(data) {
    console.log("URL : ", DoctorConfiguration.ChangePatientStatus);
    return axiosServices.Patch(
      DoctorConfiguration.ChangePatientStatus,
      data,
      false
    );
  }

  GetAllPatientList(data) {
    console.log("URL : ", DoctorConfiguration.GetAllPatientList);
    return axiosServices.Get(
      DoctorConfiguration.GetAllPatientList + data,
      false
    );
  }

  AddPatientReport(data) {
    console.log("URL : ", DoctorConfiguration.AddPatientReport);
    return axiosServices.post(
      DoctorConfiguration.AddPatientReport,
      data,
      false
    );
  }

  GetPatientReport(data) {
    console.log("URL : ", DoctorConfiguration.GetPatientReport);
    return axiosServices.Get(
      DoctorConfiguration.GetPatientReport + data,
      false
    );
  }

  GetFeedback(data) {
    console.log("URL : ", DoctorConfiguration.GetFeedback);
    return axiosServices.Get(DoctorConfiguration.GetFeedback + data, false);
  }

  DeleteFeedback(data){
    console.log("URL : ", DoctorConfiguration.DeleteFeedback);
    return axiosServices.Delete(DoctorConfiguration.DeleteFeedback + data, false);
  }
}
