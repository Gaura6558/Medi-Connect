import AxiosServices from "./AxiosServices";
import ProductConfiguration from "../configurations/ProductConfiguration";

const axiosServices = new AxiosServices();

export default class ProductServices {
  //AddMenuItem GetMenuItem UpdateMenuItem DeleteMenuItem GetCustomerOrderList UpdateOrderStatus

  RegisterAppointment(data) {
    return axiosServices.post(
      ProductConfiguration.RegisterAppointment,
      data,
      false
    );
  }

  GetUserAppointments(data) {
    return axiosServices.post(
      ProductConfiguration.GetUserAppointments,
      data,
      false
    );
  }

  UpdateAppointment(data) {
    return axiosServices.Patch(
      ProductConfiguration.UpdateAppointment,
      data,
      false
    );
  }

  CancelAppointments(data) {
    return axiosServices.Delete(
      ProductConfiguration.CancelAppointments + data,
      false
    );
  }

  UpdateAppointmentStatus(data) {
    return axiosServices.Patch(
      ProductConfiguration.UpdateAppointmentStatus,
      data,
      false
    );
  }

  PayBill(data) {
    return axiosServices.Patch(ProductConfiguration.PayBill + data, false);
  }
}
