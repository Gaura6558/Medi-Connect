module.exports = {
  Parent: "https://localhost:7096/",
};
