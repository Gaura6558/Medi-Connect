const ParentConfiguration = require("./ParentConfiguration");

module.exports = {
  GetDoctorList: ParentConfiguration.Parent + "api/Patient/GetDoctorList",
  ChangePatientStatus:
    ParentConfiguration.Parent + "api/Doctor/ChangePatientStatus",
  GetAllPatientList:
    ParentConfiguration.Parent + "api/Doctor/GetAllPatientList?DoctorUserID=",
  AddPatientReport: ParentConfiguration.Parent + "api/Doctor/AddPatientReport",
  GetPatientReport:
    ParentConfiguration.Parent + "api/Doctor/GetPatientReport?PatientUserID=",
  GetFeedback:
    ParentConfiguration.Parent + "api/Doctor/GetFeedback?DoctorUserID=",
  DeleteFeedback:
    ParentConfiguration.Parent + "api/Doctor/DeleteFeedback?FeedbackID=",
};
