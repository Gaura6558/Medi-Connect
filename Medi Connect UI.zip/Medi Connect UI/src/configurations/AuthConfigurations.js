const ParentConfiguration = require("./ParentConfiguration");

module.exports = {
  SignUp: ParentConfiguration.Parent + "api/Auth/Registration",
  SignIn: ParentConfiguration.Parent + "api/Auth/LogIn",
};
