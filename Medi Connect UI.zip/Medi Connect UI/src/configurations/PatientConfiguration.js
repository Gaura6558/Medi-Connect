const ParentConfiguration = require("./ParentConfiguration");

module.exports = {
  GetAllCityAndSpecializationList:
    ParentConfiguration.Parent + "api/Patient/GetAllCityAndSpecializationList",
  AddPatient: ParentConfiguration.Parent + "api/Patient/AddPatient",
  GetPatient: ParentConfiguration.Parent + "api/Patient/GetPatient",
  SendFeedback: ParentConfiguration.Parent + "api/Patient/SendFeedback",
};
