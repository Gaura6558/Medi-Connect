const ParentConfiguration = require("./ParentConfiguration");

//AddMenuItem GetMenuItem UpdateMenuItem DeleteMenuItem GetCustomerOrderList UpdateOrderStatus
module.exports = {
  RegisterAppointment: ParentConfiguration.Parent + "api/ClinicManagement/RegisterAppointment",
  GetUserAppointments: ParentConfiguration.Parent + "api/ClinicManagement/GetUserAppointments",
  UpdateAppointment: ParentConfiguration.Parent + "api/ClinicManagement/UpdateAppointment",
  CancelAppointments:ParentConfiguration.Parent + "api/ClinicManagement/CancelAppointments?AppointmentID=",
  UpdateAppointmentStatus:ParentConfiguration.Parent + "api/Doctor/UpdateAppointmentStatus",
  PayBill:ParentConfiguration.Parent + "api/ClinicManagement/PayBill?AppointmentID="
};
