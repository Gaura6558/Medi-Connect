const ParentConfiguration = require("./ParentConfiguration");

module.exports = {
  //AddToCart GetCarts GetOrderHistory OrderItem PaymentGetaway RemoveCart
  AddToCart: ParentConfiguration.Parent + "api/Customer/AddToCart",
  GetCarts: ParentConfiguration.Parent + "api/Customer/GetCarts",
  GetOrderHistory: ParentConfiguration.Parent + "api/Customer/GetOrderHistory",
  OrderItem: ParentConfiguration.Parent + "api/Customer/OrderItem",
  PaymentGetaway: ParentConfiguration.Parent + "api/Customer/PaymentGetaway",
  RemoveCart: ParentConfiguration.Parent + "api/Customer/RemoveCart?CartID=",
  CancleOrder:ParentConfiguration.Parent + "api/Customer/CancleOrder?OrderID=",
};
