import React, { Component } from "react";
import AuthServices from "../services/AuthServices";
import "./SignIn.css";
import TextField from "@material-ui/core/TextField";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Button from "@material-ui/core/Button";
import Snackbar from "@material-ui/core/Snackbar";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";

const authServices = new AuthServices();

export default class SignIn extends Component {
  constructor() {
    super();
    this.state = {
      Radiovalue: "DOCTOR",
      EmailID: "",
      EmailIDFlag: false,
      Password: "",
      PasswordFlag: false,
      open: false,
      Message: "",
    };
  }

  handleClose = (e, reason) => {
    if (reason === "clickaway") {
      return;
    }
    this.setState({ open: false });
  };

  handleRadioChange = (e) => {
    this.setState({ Radiovalue: e.target.value });
  };

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState(
      { [name]: value },
      console.log("Name : ", name, "Value : ", value)
    );
  };

  handleSignUp = (e) => {
    this.props.history.push("/");
  };

  CheckValidation() {
    console.log("CheckValidation Calling...");

    this.setState({ EmailIDFlag: false, PasswordFlag: false });

    if (this.state.EmailID === "") {
      this.setState({ EmailIDFlag: true });
    }
    if (this.state.Password === "") {
      this.setState({ PasswordFlag: true });
    }
  }

  handleSubmit = (e) => {
    this.CheckValidation();
    if (this.state.EmailID !== "" && this.state.Password !== "") {
      console.log("Acceptable");
      let data = {
        emailID: this.state.EmailID,
        password: this.state.Password,
        role: this.state.Radiovalue,
      };
      authServices
        .SignIn(data)
        .then((data) => {
          console.log("Sign In Data : ", data);
          if (data.data.isSuccess) {
            debugger;
            if (data.data.data.role === "PATIENT") {
              //PATIENT_TOKEN, PATIENT_USERID, PATIENT_USERNAME
              localStorage.setItem("PATIENT_TOKEN", data.data.token);
              localStorage.setItem("PATIENT_USERID", data.data.data.id);
              localStorage.setItem("PATIENT_USERNAME", data.data.data.name);
              localStorage.setItem("PATIENT_CITY", data.data.data.city);
              localStorage.setItem("OpenHome", true);
              localStorage.setItem("OpenUserHistory", false);
              localStorage.setItem("OpenUserReport", false);
              this.props.history.push("/UserDashboard");
            } else {
              localStorage.setItem("DOCTOR_TOKEN", data.data.token);
              localStorage.setItem("DOCTOR_USERID", data.data.data.id);
              localStorage.setItem("OpenUserHome", true);
              localStorage.setItem("OpenHistory", false);
              localStorage.setItem("OpenFeedback", false);
              this.props.history.push("/AdminDashboard");
            }
          } else {
            console.log("Something Went Wrong");
            this.setState({ open: true, Message: data.data.message });
          }
        })
        .catch((error) => {
          console.log("Sign In Error : ", error);
          this.setState({ open: true, Message: "Something Went Wrong" });
        });
    } else {
      console.log("Not Acceptable");
      this.setState({ open: true, Message: "Please Field Mandetory Field" });
    }
  };

  render() {
    console.log("State : ", this.state);
    return (
      <div className="SignIn-Container">
        <div className="SignUp-SubContainer">
          <div className="Title">Medi Connect</div>
          <div className="Header_Container">Log In</div>
          <div className="Body">
            <form className="form">
              <TextField
                className="TextField"
                name="EmailID"
                label="EmailID"
                variant="outlined"
                size="small"
                style={{ margin: 20 }}
                error={this.state.EmailIDFlag}
                value={this.state.EmailID}
                onChange={this.handleChange}
              />
              <TextField
                className="TextField"
                type="password"
                name="Password"
                label="Password"
                variant="outlined"
                size="small"
                style={{ margin: 20 }}
                error={this.state.PasswordFlag}
                value={this.state.Password}
                onChange={this.handleChange}
              />
              {/* <RadioGroup
                className="Roles"
                name="Role"
                value={this.state.Radiovalue}
                onChange={this.handleRadioChange}
              >
                <FormControlLabel
                  className="RoleValue"
                  value="DOCTOR"
                  control={<Radio />}
                  label="Doctor"
                />
                <FormControlLabel
                  className="RoleValue"
                  value="PATIENT"
                  control={<Radio />}
                  label="Patient"
                />
              </RadioGroup> */}
            </form>
          </div>
          <div className="Buttons" style={{ alignItems: "flex-start" }}>
            <Button className="Btn" color="primary" onClick={this.handleSignUp}>
              Create New Account
            </Button>
            <Button
              className="Btn"
              variant="contained"
              color="primary"
              onClick={this.handleSubmit}
            >
              Sign In
            </Button>
          </div>
        </div>
        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={this.state.open}
          autoHideDuration={6000}
          onClose={this.handleClose}
          message={this.state.Message}
          action={
            <React.Fragment>
              <Button color="secondary" size="small" onClick={this.handleClose}>
                UNDO
              </Button>
              <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={this.handleClose}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </React.Fragment>
          }
        />
      </div>
    );
  }
}
