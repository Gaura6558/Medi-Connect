import React, { Component } from "react";

import "./UserDashBoard.css";
import GetUserMenus from "../Product/GetUserMenus";
import GetUserHistory from "../Product/GetUserHistory";
import ProductServices from "../../services/ProductServices";
import CustomerServices from "../../services/CustomerServices";
import GetUserReport from "../Product/GetUserReport";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

import TimelineIcon from "@material-ui/icons/Timeline";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import HomeIcon from "@material-ui/icons/Home";
import FeedbackIcon from "@material-ui/icons/Feedback";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import CreateIcon from "@material-ui/icons/Create";
import LocalHospitalIcon from "@material-ui/icons/LocalHospital";
const productServices = new ProductServices();
const customerServices = new CustomerServices();

export default class UserDashBoard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      //PATIENT_TOKEN, PATIENT_USERID, PATIENT_USERNAME
      Patient: [],
      ItemTypeRadioValue: "Pending",
      //
      FeedBack: "",
      RatingValue: 1,
      FeedBackFlag: false,
      //
      Message: "",
      //
      NumberOfRecordPerPage: 6,
      //
      PageNumber: 1,
      //
      TotalPages: 0,
      TotalRecords: 0,

      Open: false, // Flag For Open Feedback
      OpenLoader: false,
      OpenSnackBar: false,

      Update: false,

      OpenUserHome: true,
      OpenUserHistory: false,
      OpenUserReport: false,
    };
  }

  componentWillMount() {
    console.log("Component will mount calling ... ");

    this.setState({
      OpenUserHome: localStorage.getItem("OpenHome") === "true" ? true : false,
      OpenUserHistory:
        localStorage.getItem("OpenUserHistory") === "true" ? true : false,
      OpenUserReport:
        localStorage.getItem("OpenUserReport") === "true" ? true : false,
    });
  }

  //
  GetUserAppointments = async (CurrentPage) => {
    console.log("Get User Appointments Calling ... ");

    let data = {
      userID: -1,
      pageNumber: CurrentPage,
      numberOfRecordPerPage: 4,
    };

    this.setState({ OpenLoader: true });

    productServices
      .GetUserAppointments(data)
      .then((data) => {
        console.log("GetUserAppointments Data : ", data);
        // debugger
        if (data.data.data === null && this.state.PageNumber > 1) {
          this.setState({ PageNumber: this.state.PageNumber - 1 });
          this.GetUserAppointments(this.state.PageNumber);
        } else {
          this.setState({
            Patient: data.data.data,
            TotalPages: data.data.totalPage,
            PageNumber: data.data.currentPage,
            OpenLoader: false,
          });
        }
      })
      .catch((error) => {
        console.log("GetUserAppointments Error : ", error);
        this.setState({ OpenLoader: false });
      });
  };

  UpdateAppointmentStatus = async (value, AppointmentID) => {
    console.log("Update Appointment Status Calling ... ");

    let data = {
      appointmentID: AppointmentID,
      status: value,
    };

    this.setState({ OpenLoader: true });

    productServices
      .UpdateAppointmentStatus(data)
      .then((data) => {
        console.log("UpdateAppointmentStatus Data : ", data);
        this.GetUserAppointments(this.state.PageNumber);
        this.setState({
          OpenLoader: false,
        });
      })
      .catch((error) => {
        console.log("UpdateAppointmentStatus Error : ", error);
        this.setState({ OpenLoader: false });
      });
  };

  handleClose = () => {
    console.log("Handle Close Calling ...");
    this.setState({
      Open: false,
      Update: false,
      OpenBookModel: false,
      FeedBackFlag: false,
    });
  };

  handleChanges = (e) => {
    const { name, value } = e.target;

    this.setState(
      { [name]: value },
      console.log("Name : ", name, " value : ", value)
    );
  };

  handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({ OpenSnackBar: false });
  };

  handlePaging = async (e, value) => {
    let state = this.state;
    console.log("Current Page : ", value);

    this.setState({
      PageNumber: value,
    });

    if (state.OpenUserHome) {
      await this.GetUserAppointments(value);
    } else if (state.OpenUserHistory) {
      await this.GetAllCardDetails(value);
    }
  };

  SignOut = async () => {
    localStorage.removeItem("PATIENT_TOKEN");
    localStorage.removeItem("PATIENT_USERID");
    localStorage.removeItem("PATIENT_USERNAME");
    localStorage.removeItem("PATIENT_CITY");
    localStorage.removeItem("OpenHome");
    localStorage.removeItem("OpenUserHistory");
    localStorage.removeItem("OpenUserReport");
    this.props.history.push("/SignIn");
  };

  //
  handleOpenHomeNav = () => {
    console.log("Handle Open Home Nav Calling .....");

    localStorage.setItem("OpenHome", true);
    localStorage.setItem("OpenUserHistory", false);
    localStorage.setItem("OpenUserReport", false);

    this.setState({
      OpenUserHome: true,
      OpenUserHistory: false,
      OpenUserReport: false,
    });
  };

  //
  handleOpenHistoryNav = () => {
    console.log("Handle Open Cart Nav Calling .....");

    localStorage.setItem("OpenHome", false);
    localStorage.setItem("OpenUserHistory", true);
    localStorage.setItem("OpenUserReport", false);
    this.setState({
      OpenUserHome: false,
      OpenUserHistory: true,
      OpenUserReport: false,
    });
  };

  handleOpenReportNav = () => {
    console.log("Handle Open Cart Nav Calling .....");

    localStorage.setItem("OpenHome", false);
    localStorage.setItem("OpenUserHistory", false);
    localStorage.setItem("OpenUserReport", true);
    this.setState({
      OpenUserHome: false,
      OpenUserHistory: false,
      OpenUserReport: true,
    });
  };

  //
  setItemTypeRadioValue = (value, AppointmentID) => {
    console.log(
      "setItemTypeRadioValue Value : ",
      value,
      " AppointmentID : ",
      AppointmentID
    );
    this.setState({ ItemTypeRadioValue: value });
    this.UpdateAppointmentStatus(value, AppointmentID);
  };

  //
  OpenUserHomeNav = () => {
    return <GetUserMenus />;
  };

  OpenUserHistoryNav = () => {
    return <GetUserHistory />;
  };

  OpenUserReportNav = () => {
    return <GetUserReport />;
  };

  handleFeedOpen = () => {
    this.setState({ Open: true });
  };

  render() {
    let state = this.state;
    let self = this;
    console.log("State : ", state);
    return (
      <div className="UserDashBoard-Container">
        <div className="Sub-Container">
          <div className="Header">
            <AppBar position="static" style={{ backgroundColor: "#202020" }}>
              <Toolbar>
                <Typography
                  variant="h6"
                  style={{
                    flexGrow: 3,
                    display: "flex",
                    padding: "5px 0 0 200px",
                    boxSizing: "border-box",
                  }}
                >
                  Medi Connect &nbsp;
                  <div style={{ margin: "0px 0 0 0" }}>
                    <LocalHospitalIcon />
                  </div>
                </Typography>

                <Typography style={{ marginRight: 300 }}>
                  User Dashboard
                </Typography>
                <Button
                  // style={{ flexGrow: 1 }}
                  color="inherit"
                  onClick={() => {
                    this.SignOut();
                  }}
                >
                  LogOut
                </Button>
              </Toolbar>
            </AppBar>
          </div>
          <div className="Body">
            <div className="Sub-Body">
              <div className="SubBody11">
                <div
                  className={state.OpenUserHome ? "NavButton1" : "NavButton2"}
                  onClick={() => {
                    this.handleOpenHomeNav();
                  }}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <HomeIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">Home</div>
                </div>
                <div
                  className={
                    state.OpenUserHistory ? "NavButton1" : "NavButton2"
                  }
                  onClick={() => {
                    this.handleOpenHistoryNav();
                  }}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <TimelineIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">History</div>
                </div>
                <div
                  className={state.OpenUserReport ? "NavButton1" : "NavButton2"}
                  onClick={() => {
                    this.handleOpenReportNav();
                  }}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <CreateIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">Report</div>
                </div>
              </div>
              <div className="SubBody22">
                <div style={{ height: "100%", width: "100%" }}>
                  {state.OpenUserHome ? this.OpenUserHomeNav() : null}
                  {state.OpenUserHistory ? this.OpenUserHistoryNav() : null}
                  {state.OpenUserReport ? this.OpenUserReportNav() : null}
                </div>
              </div>
            </div>
          </div>
        </div>

        <Modal
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          open={this.state.Open}
          // open={true}
          onClose={this.handleClose}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
        >
          <Fade in={this.state.Open}>
            <div
              className="p-5"
              style={{
                backgroundColor: "white",
                boxShadow: "5",
                padding: "2px 4px 3px",
                width: "600px",
                height: "580px",
                display: "flex",
                fontWeight: 500,
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
              }}
            >
              <div className="form-group mb-5">
                <label>Feedback</label>
                <textarea
                  rows={10}
                  className="form-control"
                  style={{ width: 450 }}
                  onChange={(event) => {
                    this.setState({ FeedBack: event.target.value });
                  }}
                ></textarea>
              </div>
              <div className="w-100 d-flex justify-content-between">
                <div
                  className="btn btn-light"
                  onClick={() => {
                    this.handleClose();
                  }}
                >
                  Cancel
                </div>
                <div
                  className="btn btn-primary"
                  onClick={() => {
                    this.handleSendFeedBack();
                  }}
                >
                  Send Feedback
                </div>
              </div>
            </div>
          </Fade>
        </Modal>

        <Backdrop
          style={{ zIndex: "1", color: "#fff" }}
          open={this.state.OpenLoader}
          onClick={() => {
            this.setState({ OpenLoader: false });
          }}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={state.OpenSnackBar}
          autoHideDuration={2000}
          onClose={this.handleSnackBarClose}
          message={state.Message}
          action={
            <React.Fragment>
              <Button
                color="secondary"
                size="small"
                onClick={this.handleSnackBarClose}
              >
                UNDO
              </Button>
              <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={this.handleSnackBarClose}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </React.Fragment>
          }
        />
      </div>
    );
  }
}
