import React, { Component } from "react";
import "./AdminDashboard.css";
import GetMenuItem from "../Product/GetMenuItem";
import GetMenuHistory from "../Product/GetMenuHistory";
import ProductServices from "../../services/ProductServices";
import CustomerServices from "../../services/CustomerServices";
import GetMenuFeedback from "../Product/GetMenuFeedback";

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import HomeIcon from "@material-ui/icons/Home";
import TimelineIcon from "@material-ui/icons/Timeline";
import FeedbackIcon from "@material-ui/icons/Feedback";
import LocalHospitalIcon from "@material-ui/icons/LocalHospital";
import DeleteIcon from "@material-ui/icons/Delete";
import Backdrop from "@material-ui/core/Backdrop";
import Pagination from "@material-ui/lab/Pagination";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";
import CircularProgress from "@material-ui/core/CircularProgress";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import SearchIcon from "@material-ui/icons/Search";
import InputBase from "@material-ui/core/InputBase";
import Rating from "@material-ui/lab/Rating";

//Table Library
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";

const productServices = new ProductServices();
const customerServices = new CustomerServices();

export default class AdminDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      //
      Patient: [],
      //
      Message: "",
      //
      NumberOfRecordPerPage: 6,
      PageNumber: 1,

      FeedbackPageNumber: 1,
      //
      TotalPages: 0,
      TotalRecords: 0,

      Open: false,
      OpenEdit: false, // Open Editing Booking Model
      OpenLoader: false,
      OpenSnackBar: false,

      OpenHome: true,
      OpenUserHistory: false,
      OpenOrderList: false,
      OpenFeedBack: false,

      Update: false,
      ShowApplicantInfo: false,
      OpenBookModel: false, //Editing Booking Application
    };
  }

  //
  componentWillMount() {
    console.log("Component will mount calling ...  State : ", this.state);
    this.setState({
      OpenHome: localStorage.getItem("OpenUserHome") === "true" ? true : false,
      OpenUserHistory:
        localStorage.getItem("OpenHistory") === "true" ? true : false,
      OpenFeedBack:
        localStorage.getItem("OpenFeedback") === "true" ? true : false,
    });

    if (localStorage.getItem("OpenUserHome") === "true") {
    } else if (localStorage.getItem("OpenHistory") === "true") {
    }
  }

  handleClose = () => {
    console.log("Handle Close Calling ...");
    this.setState({
      open: false,
      Update: false,
      OpenEdit: false,
      OpenBookModel: false,
    });
  };

  handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({ OpenSnackBar: false });
  };

  //
  handleOpenHomeNav = () => {
    console.log("Handle Open List Calling ... ");
    //
    localStorage.setItem("OpenUserHome", true);
    localStorage.setItem("OpenHistory", false);
    localStorage.setItem("OpenFeedback", false);
    //
    this.setState({
      PageNumber: 1,
      OpenHome: true,
      OpenUserHistory: false,
      OpenOrderList: false,
      OpenFeedBack: false,
    });
  };

  handleOpenHistoryNav = () => {
    console.log("Handle Open List Calling ... ");
    //
    localStorage.setItem("OpenUserHome", false);
    localStorage.setItem("OpenHistory", true);
    localStorage.setItem("OpenFeedback", false);
    //
    this.setState({
      OpenHome: false,
      OpenUserHistory: true,
      OpenOrderList: false,
      OpenFeedBack: false,
    });
  };

  handleOpenFeedbackNav = () => {
    console.log("Handle Open List Calling ... ");
    //
    localStorage.setItem("OpenUserHome", false);
    localStorage.setItem("OpenHistory", false);
    localStorage.setItem("OpenFeedback", true);
    //
    this.setState({
      OpenHome: false,
      OpenUserHistory: false,
      OpenOrderList: false,
      OpenFeedBack: true,
    });
  };

  handlePaging = async (e, value) => {
    let state = this.state;
    console.log("Current Page : ", value);

    this.setState({
      PageNumber: value,
    });

    if (state.OpenHome) {
      await this.GetMenuItem(value);
    }
  };

  setItemTypeRadioValue = async (ID, value) => {
    console.log("setItemTypeRadioValue Value : ", value);

    if (this.state.OpenHome) {
      this.setState({ ItemTypeRadioValue: value });
      this.GetMenuItem(1, value);
    } else if (this.state.OpenOrderList) {
      this.setState({ OrderStatusRadioValue: value });
      await this.UpdateOrderStatus(ID, value);
    }
  };

  SignOut = async () => {
    localStorage.removeItem("DOCTOR_TOKEN");
    localStorage.removeItem("DOCTOR_USERID");
    localStorage.removeItem("OpenUserHome");
    localStorage.removeItem("OpenHistory");
    localStorage.removeItem("OpenFeedback");

    this.props.history.push("/SignIn");
  };
  //
  OpenHomeNav = () => {
    return <GetMenuItem />;
  };

  OpenHistoryNav = () => {
    return <GetMenuHistory />;
  };

  OpenFeedbackNav = () => {
    return <GetMenuFeedback />;
  };

  render() {
    let state = this.state;
    let self = this;
    console.log("state : ", state);
    return (
      <div className="AdminDashboard-Container">
        <div className="Sub-Container">
          <div className="Header">
            <AppBar position="static" style={{ backgroundColor: "#202020" }}>
              <Toolbar>
                <Typography
                  variant="h6"
                  style={{
                    flexGrow: 3,
                    display: "flex",
                    padding: "5px 0 0 200px",
                    boxSizing: "border-box",
                  }}
                >
                  Medi Connect &nbsp;
                  <div style={{ margin: "0px 0 0 0" }}>
                    <LocalHospitalIcon />
                  </div>
                </Typography>
                <Typography style={{ marginRight: 300 }}>
                  Admin Dashboard
                </Typography>
                <Button
                  color="inherit"
                  onClick={() => {
                    this.SignOut();
                  }}
                >
                  LogOut
                </Button>
              </Toolbar>
            </AppBar>
          </div>
          <div className="Body">
            <div className="Sub-Body">
              <div className="SubBody11">
                <div
                  className={state.OpenHome ? "NavButton1" : "NavButton2"}
                  onClick={this.handleOpenHomeNav}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <HomeIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">Home</div>
                </div>
                <div
                  className={
                    state.OpenUserHistory ? "NavButton1" : "NavButton2"
                  }
                  onClick={this.handleOpenHistoryNav}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <TimelineIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">Patient History</div>
                </div>
                <div
                  className={state.OpenFeedBack ? "NavButton1" : "NavButton2"}
                  onClick={this.handleOpenFeedbackNav}
                >
                  <IconButton edge="start" className="NavBtn" color="inherit">
                    <FeedbackIcon style={{ color: "white" }} />
                  </IconButton>
                  <div className="NavButtonText">Feedback</div>
                </div>
              </div>
              <div className="SubBody21">
                <div style={{ height: "100%", width: "100%" }}>
                  {state.OpenHome ? this.OpenHomeNav() : <></>}
                  {state.OpenUserHistory ? this.OpenHistoryNav() : <></>}
                  {state.OpenFeedBack ? this.OpenFeedbackNav() : <></>}
                </div>
              </div>
            </div>
          </div>
        </div>

        <Backdrop
          style={{ zIndex: "1", color: "#fff" }}
          open={this.state.OpenLoader}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={state.OpenSnackBar}
          autoHideDuration={2000}
          onClose={this.handleSnackBarClose}
          message={state.Message}
          action={
            <React.Fragment>
              <Button
                color="secondary"
                size="small"
                onClick={this.handleSnackBarClose}
              >
                UNDO
              </Button>
              <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={this.handleSnackBarClose}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </React.Fragment>
          }
        />
      </div>
    );
  }
}
