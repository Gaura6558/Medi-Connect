import React, { useState, useEffect } from "react";
import "./GetProduct.css";
import DoctorServices from "../../services/DoctorServices";
import Button from "@material-ui/core/Button";
import Pagination from "@material-ui/lab/Pagination";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import ClearIcon from "@material-ui/icons/Clear";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";

import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

import PaymentIcon from "@material-ui/icons/Payment";
import TextField from "@material-ui/core/TextField";

const doctorServices = new DoctorServices();

export default function GetProduct(props) {
  const [Message, setMessage] = useState("");
  const [OpenSnackBar, setOpenSnackBar] = useState(false);
  const [OpenLoader, setOpenLoader] = useState(false);
  const [List, setList] = useState([]);

  useEffect(() => {
    GetAllPatientList();
  }, []);

  const GetAllPatientList = () => {
    doctorServices
      .GetAllPatientList(Number(localStorage.getItem("DOCTOR_USERID")))
      .then((data) => {
        console.log("GetAllPatientList Data : ", data);
        debugger;
        if (data.data.isSuccess) {
          setList(data.data.data);
        }
      })
      .catch((error) => {
        console.log("GetAllPatientList Error : ", error);
      });
  };

  const handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnackBar(false);
  };

  const handleChangeAppointmentStatus = (_data, _status) => {
    let data = {
      id: _data.id,
      status: _status,
    };
    doctorServices
      .ChangePatientStatus(data)
      .then((data) => {
        console.log("ChangePatientStatus Data : ", data);
        if (data.data.isSuccess) {
          setMessage(data.data.message);
          setOpenSnackBar(true);
          GetAllPatientList();
        }
      })
      .catch((error) => {
        console.error("ChangePatientStatus Error : ", error);
        setMessage("Something went Wrong");
        setOpenSnackBar(true);
      });
  };

  return (
    <div className="GetProduct-Container">
      <div className="GetProduct-SubContainer">
        <div className="GetProduct-SubContainer1">
          <div className="GetProduct-SubContainer11">
            <TableContainer component={Paper}>
              <Table className="" aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      align="center"
                      style={{ width: 50, fontWeight: 600, fontSize: 15 }}
                    >
                      ID
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 150, fontWeight: 600, fontSize: 15 }}
                    >
                      Patient Name
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Date
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Time
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Status
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 200, fontWeight: 600, fontSize: 15 }}
                    ></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Array.isArray(List) && List.length > 0
                    ? List.map(function (data, index) {
                        return data.status === "Pending" ? (
                          <>
                            <TableRow key={index}>
                              <TableCell align="center" style={{ width: 50 }}>
                                {data.id}
                              </TableCell>
                              <TableCell align="center" style={{ width: 150 }}>
                                {data.patientName}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.appointmentDate}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.appointmentTime}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.status}
                              </TableCell>
                              <TableCell align="center" style={{ width: 200 }}>
                                {data.status !== "confirm" ? (
                                  <div
                                    className="btn btn-success"
                                    onClick={() => {
                                      handleChangeAppointmentStatus(
                                        data,
                                        "confirm"
                                      );
                                    }}
                                  >
                                    Confirm
                                  </div>
                                ) : null}
                                {data.status !== "cancel" ? (
                                  <div
                                    className="btn btn-danger mx-2"
                                    onClick={() => {
                                      handleChangeAppointmentStatus(
                                        data,
                                        "cancel"
                                      );
                                    }}
                                  >
                                    Cancel
                                  </div>
                                ) : null}
                              </TableCell>
                            </TableRow>
                          </>
                        ) : (
                          <></>
                        );
                      })
                    : null}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
      </div>

      {/* <Modal
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={Data.Open}
        // open={true}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={Data.Open}>
          <div
            style={{
              backgroundColor: "white",
              boxShadow: "5",
              padding: "2px 4px 3px",
              width: "600px",
              height: "350px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                fontWidth: "600",
                fontSize: "18px",
                fontFamily: "Roboto",
                margin: "20px",
              }}
            >
              Appointment ID : {Data.AppointmentID}
            </div>
            <div
              className=""
              style={{
                fontWidth: "600",
                fontSize: "18px",
                fontFamily: "Roboto",
                margin: "20px",
              }}
            >
              Are You Sure To Pay Bill ?
            </div>
            <div style={{ display: "flex" }}>
              <Button
                variant="contained"
                color="primary"
                component="span"
                style={{ margin: "10px 10px 0 0" }}
                // onClick={() => {
                //   handlePay();
                // }}
              >
                Pay
              </Button>
              <Button
                variant="outlined"
                style={{ margin: "10px 0 0 10px" }}
                onClick={handleClose}
              >
                Cancle
              </Button>
            </div>
          </div>
        </Fade>
      </Modal> */}

      <Backdrop style={{ zIndex: "1", color: "#fff" }} open={OpenLoader}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={OpenSnackBar}
        autoHideDuration={2000}
        onClose={handleSnackBarClose}
        message={Message}
        action={
          <React.Fragment>
            <Button
              color="secondary"
              size="small"
              onClick={handleSnackBarClose}
            >
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleSnackBarClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
}
