import React, { useState, useEffect } from "react";
import "./GetUserMenus.css";

import DoctorServices from "../../services/DoctorServices";
import PatientServices from "../../services/PatientServices";

import Button from "@material-ui/core/Button";
import Pagination from "@material-ui/lab/Pagination";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import RemoveIcon from "@material-ui/icons/Remove";
import AddIcon from "@material-ui/icons/Add";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import PaymentIcon from "@material-ui/icons/Payment";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

const doctorServices = new DoctorServices();
const patientServices = new PatientServices();

export default function GetUserMenus(props) {
  const [Message, setMessage] = useState("");
  const [OpenSnackBar, setOpenSnackBar] = useState(false);
  const [city, setcity] = useState("");
  const [specialization, setspecialization] = useState("");
  const [OpenLoader, setOpenLoader] = useState(false);
  const [PageNumber, setPageNumber] = useState(0);
  const [OpenModel, setOpenModel] = useState(false);
  const [List, setList] = useState([]);
  const [cityList, setcityList] = useState([]);
  const [specializationList, setspecializationList] = useState([]);
  const [Data, setData] = useState(Object);
  const [PatientData, setPatientData] = useState({
    Discription: "",
    Date: "",
    Time: "",

    DiscriptionFlag: false,
    DateFlag: false,
    TimeFlag: false,
  });

  useEffect(() => {
    GetAllCityAndSpecializationList();
    GetDoctorList();
  }, []);

  const GetAllCityAndSpecializationList = () => {
    patientServices
      .GetAllCityAndSpecializationList()
      .then((data) => {
        console.log("GetAllCityAndSpecializationList Data : ", data.data);
        if (data.data.isSuccess) {
          setcityList(data.data.city);
          setspecializationList(data.data.specialization);
        }
      })
      .catch((error) => {
        console.log("GetAllCityAndSpecializationList Error : ", error);
      });
  };

  const handleSelectCity = () => {
    console.log("city Name : ", document.getElementById("chooseCity").value);
    setcity(document.getElementById("chooseCity").value);
    GetDoctorList();
  };

  const handleSelectSpecialization = () => {
    console.log(
      "Specialization Name : ",
      document.getElementById("chooseSpecialization").value
    );
    setspecialization(document.getElementById("chooseSpecialization").value);
    GetDoctorList();
  };

  const GetDoctorList = () => {
    let data = {
      city: document.getElementById("chooseCity").value,
      specification: document.getElementById("chooseSpecialization").value,
    };
    doctorServices
      .GetDoctorList(data)
      .then((data) => {
        console.log("GetDoctorList Data : ", data.data);
        // debugger;
        if (data.data.isSuccess) {
          setList(data.data.data);
        }
      })
      .catch((error) => {
        console.log("GetDoctorList Error : ", error);
      });
  };

  const handleBookAppointment = (data) => {
    console.log("Doctor Data", data);
    setData(data);
    setOpenModel(true);
  };

  const handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnackBar(false);
  };

  const handleCloseModel = () => {
    setOpenModel(false);
  };

  const validation = () => {
    setPatientData({
      ...PatientData,
      DiscriptionFlag: false,
      DateFlag: false,
      TimeFlag: false,
    });
    let value = true;
    if (PatientData.Discription === "") {
      value = false;
      setPatientData({
        ...PatientData,
        DiscriptionFlag: true,
      });
    }
    if (PatientData.Date === "") {
      value = false;
      setPatientData({
        ...PatientData,
        DateFlag: true,
      });
    }
    if (PatientData.Time === "") {
      value = false;
      setPatientData({
        ...PatientData,
        TimeFlag: true,
      });
    }

    return value;
  };

  const handleAppointmentBook = () => {
    if (validation()) {
      console.log("Validation Passed");
      let data = {
        doctorUserID: Data.id,
        patientUserID: localStorage.getItem("PATIENT_USERID"),
        patientName: localStorage.getItem("PATIENT_USERNAME"),
        patientCity: localStorage.getItem("PATIENT_CITY"),
        description: PatientData.Discription,
        appointmentDate: PatientData.Date,
        appointmentTime: PatientData.Time,
      };

      patientServices
        .AddPatient(data)
        .then((data) => {
          debugger;
          console.log("AddPatient Data : ", data);
          if (data.data.isSuccess) {
            setMessage(data.data.message);
            setOpenSnackBar(true);
            setOpenModel(false);
            setPatientData({
              ...PatientData,
              Discription: "",
              Date: "",
              Time: "",
            });
          }
        })
        .catch((error) => {
          console.log("AddPatient Error : ", error);
          setMessage("Something Went Wrong");
          setOpenSnackBar(true);
        });
    } else {
      console.log("Validation Failed");
      setMessage("Please Enter Required Field");
      setOpenSnackBar(true);
    }
  };

  return (
    <div className="GetUserMenus-Container">
      <div className="GetUserMenus-Header w-100 border-white">
        <div className="d-flex p-2">
          <select
            className="form-control mx-2 w-25 "
            id="chooseCity"
            value={city}
            onChange={() => {
              handleSelectCity(city);
            }}
          >
            <option value="" className="form-control">
              select city option
            </option>
            {Array.isArray(cityList) && cityList.length > 0
              ? cityList.map(function (data, index) {
                  return <option value={data}>{data}</option>;
                })
              : null}
          </select>
          <select
            className="form-control me-5 w-25"
            id="chooseSpecialization"
            value={specialization}
            onChange={() => {
              handleSelectSpecialization();
            }}
          >
            <option value="">select specialization option </option>

            {Array.isArray(specializationList) && specializationList.length > 0
              ? specializationList.map(function (data, index) {
                  return <option value={data}>{data}</option>;
                })
              : null}
          </select>
        </div>
      </div>
      <div className="GetUserMenus-SubContainer">
        <TableContainer component={Paper}>
          <Table className="" aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell
                  align="center"
                  style={{ width: 50, fontWeight: 600, fontSize: 15 }}
                >
                  Doctor ID
                </TableCell>
                <TableCell
                  align="center"
                  style={{ width: 200, fontWeight: 600, fontSize: 15 }}
                >
                  Doctor Name
                </TableCell>
                <TableCell
                  align="center"
                  style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                >
                  Specialization
                </TableCell>
                <TableCell
                  align="center"
                  style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                >
                  City
                </TableCell>
                <TableCell
                  align="center"
                  style={{ width: 210, fontWeight: 600, fontSize: 15 }}
                ></TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {Array.isArray(List) && List.length > 0
                ? List.map(function (data, index) {
                    return (
                      <TableRow key={index}>
                        <>
                          <TableCell align="center" style={{ width: 200 }}>
                            {data.id}
                          </TableCell>
                          <TableCell align="center" style={{ width: 200 }}>
                            {data.name}
                          </TableCell>
                          <TableCell align="center" style={{ width: 100 }}>
                            {data.specialization}
                          </TableCell>
                          <TableCell align="center" style={{ width: 100 }}>
                            {data.city}
                          </TableCell>
                          <TableCell
                            align="center"
                            style={{
                              width: 210,
                              // border: "0.5px solid black",
                            }}
                          >
                            <div
                              className="btn btn-info"
                              onClick={() => {
                                handleBookAppointment(data);
                              }}
                            >
                              Book Appointment
                            </div>
                          </TableCell>
                        </>
                      </TableRow>
                    );
                  })
                : null}
            </TableBody>
          </Table>
        </TableContainer>

        <Modal
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          open={OpenModel || false}
          // open={true}
          onClose={() => {
            handleCloseModel();
          }}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
        >
          <Fade in={OpenModel || false}>
            <div
              className="p-5"
              style={{
                backgroundColor: "white",
                boxShadow: "5",
                padding: "2px 4px 3px",
                width: "500px",
                height: "500px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
                fontWeight: 500,
              }}
            >
              <div className="mb-3">Doctor ID :&nbsp;{Data.id}</div>
              <div className="mb-3">Doctor Name :&nbsp;{Data.name}</div>
              <div className="mb-3">
                Doctor Specialization :&nbsp;{Data.specialization}
              </div>
              <div>
                <label className="form-label">Description</label>
                <textarea
                  type="text"
                  multiple
                  rows="5"
                  style={{ width: 400 }}
                  className="form-control"
                  value={PatientData.Discription}
                  onChange={(event) => {
                    setPatientData({
                      ...PatientData,
                      Discription: event.target.value,
                    });
                  }}
                ></textarea>
              </div>
              <div className="d-flex m-4">
                <input
                  type="date"
                  className="form-control mx-3"
                  onChange={(event) => {
                    setPatientData({
                      ...PatientData,
                      Date: event.target.value,
                    });
                  }}
                ></input>
                <input
                  type="time"
                  className="form-control"
                  onChange={(event) => {
                    setPatientData({
                      ...PatientData,
                      Time: event.target.value,
                    });
                  }}
                ></input>
              </div>
              <div className="w-100 d-flex justify-content-between mt-3">
                <div
                  className="btn btn-light"
                  onClick={() => {
                    setOpenModel(false);
                  }}
                >
                  Cancel
                </div>
                <div
                  className="btn btn-success"
                  onClick={() => {
                    handleAppointmentBook();
                  }}
                >
                  Book
                </div>
              </div>
            </div>
          </Fade>
        </Modal>
      </div>
      <Backdrop style={{ zIndex: "1", color: "#fff" }} open={OpenLoader}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={OpenSnackBar}
        autoHideDuration={2000}
        onClose={handleSnackBarClose}
        message={Message}
        action={
          <React.Fragment>
            <Button
              color="secondary"
              size="small"
              onClick={handleSnackBarClose}
            >
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleSnackBarClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
}
