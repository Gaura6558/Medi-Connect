import React, { useState } from "react";
import "./GetUserReport.css";

import DoctorServices from "../../services/DoctorServices";

import Button from "@material-ui/core/Button";
import Pagination from "@material-ui/lab/Pagination";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import RemoveIcon from "@material-ui/icons/Remove";
import AddIcon from "@material-ui/icons/Add";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import PaymentIcon from "@material-ui/icons/Payment";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

const doctorServices = new DoctorServices();

export default function GetUserReport() {
  const [Message, setMessage] = useState("");
  const [OpenSnackBar, setOpenSnackBar] = useState(false);
  const [OpenLoader, setOpenLoader] = useState(false);
  const [OpenReport, setOpenReport] = useState(false);
  const [List, setList] = useState([]);
  const [PatientReportList, setPatientReportList] = useState([]);
  const [Open, setOpen] = useState(false);
  const [Data, setData] = useState({
    PatientUserID: 0,
    DoctorUserID: 0,
    ReportDescription: "",

    ReportDescriptionFlag: false,
  });

  React.useEffect(() => {
    GetPatientReport(Number(localStorage.getItem("PATIENT_USERID")));
  }, []);

  const GetPatientReport = (PatientUserID) => {
    doctorServices
      .GetPatientReport(Number(PatientUserID))
      .then((data) => {
        console.log("GetPatientReport Data : ", data);
        debugger;
        if (data.data.isSuccess) {
          setPatientReportList(data.data.data);
          setOpenReport(true);
        }
        setMessage(data.data.message);
        setOpenSnackBar(true);
      })
      .catch((error) => {
        console.error("GetPatientReport Error : ", error);
        setMessage("Something went wrong");
        setOpenSnackBar(true);
      });
  };

  return (
    <div className="GetUserReport-Container p-1">
      <TableContainer component={Paper}>
        <Table className="" aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell
                align="center"
                style={{ width: 50, fontWeight: 600, fontSize: 15 }}
              >
                Report ID
              </TableCell>
              <TableCell
                align="center"
                style={{ width: 150, fontWeight: 600, fontSize: 15 }}
              >
                Doctor Name
              </TableCell>
              {/* <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Date & Time
                    </TableCell> */}
              <TableCell
                align="center"
                style={{ width: 250, fontWeight: 600, fontSize: 15 }}
              >
                Report
              </TableCell>
              {/* <TableCell
                      align="center"
                      style={{ width: 300, fontWeight: 600, fontSize: 15 }}
                    ></TableCell> */}
            </TableRow>
          </TableHead>
          <TableBody>
            {Array.isArray(PatientReportList) && PatientReportList.length > 0
              ? PatientReportList.map(function (data, index) {
                  return data.status !== "pending" ? (
                    <>
                      <TableRow key={data.id}>
                        <TableCell align="center" style={{ width: 50 }}>
                          {data.id}
                        </TableCell>
                        <TableCell align="center" style={{ width: 200 }}>
                          {data.doctorUserdata.name}
                        </TableCell>
                        <TableCell align="center" style={{ width: 50 }}>
                          {data.report}
                        </TableCell>
                      </TableRow>
                    </>
                  ) : (
                    <></>
                  );
                })
              : null}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}
