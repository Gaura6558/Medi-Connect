import React, { useState, useEffect } from "react";
import "./GetProduct.css";
import DoctorServices from "../../services/DoctorServices";
import Button from "@material-ui/core/Button";
import Pagination from "@material-ui/lab/Pagination";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import ClearIcon from "@material-ui/icons/Clear";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";

import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

import PaymentIcon from "@material-ui/icons/Payment";
import TextField from "@material-ui/core/TextField";

const doctorServices = new DoctorServices();

export default function GetMenuHistory() {
  const [Message, setMessage] = useState("");
  const [OpenSnackBar, setOpenSnackBar] = useState(false);
  const [OpenLoader, setOpenLoader] = useState(false);
  const [OpenReport, setOpenReport] = useState(false);
  const [List, setList] = useState([]);
  const [PatientReportList, setPatientReportList] = useState([]);
  const [Open, setOpen] = useState(false);
  const [Data, setData] = useState({
    PatientUserID: 0,
    DoctorUserID: 0,
    ReportDescription: "",

    ReportDescriptionFlag: false,
  });

  useEffect(() => {
    GetAllPatientList();
  }, []);

  const GetAllPatientList = () => {
    doctorServices
      .GetAllPatientList(Number(localStorage.getItem("DOCTOR_USERID")))
      .then((data) => {
        console.log("GetAllPatientList Data : ", data);
        debugger;
        if (data.data.isSuccess) {
          setList(data.data.data);
        }
      })
      .catch((error) => {
        console.log("GetAllPatientList Error : ", error);
      });
  };

  const handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnackBar(false);
  };

  const handleChangeAppointmentStatus = (_data, _status) => {
    let data = {
      id: _data.id,
      status: _status,
    };
    doctorServices
      .ChangePatientStatus(data)
      .then((data) => {
        console.log("ChangePatientStatus Data : ", data);
        if (data.data.isSuccess) {
          setMessage(data.data.message);
          setOpenSnackBar(true);
          GetAllPatientList();
        }
      })
      .catch((error) => {
        console.error("ChangePatientStatus Error : ", error);
        setMessage("Something went Wrong");
        setOpenSnackBar(true);
      });
  };

  const handleAddReport = (data) => {
    console.log("handleAddReport Data : ", data);
    setData({
      ...Data,
      PatientUserID: data.patientUserID,
      DoctorUserID: data.doctorUserID,
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setOpenReport(false);
  };

  const handleSendReport = () => {
    debugger;
    if (Data.ReportDescription === "") {
      setMessage("Please Enter Required Field");
      setOpenSnackBar(true);
      return;
    }

    let data = {
      patientUserID: Data.PatientUserID,
      doctorUserID: Data.DoctorUserID,
      report: Data.ReportDescription,
    };

    doctorServices
      .AddPatientReport(data)
      .then((data) => {
        console.log("AddPatientReport Data : ", data.data);
        if (data.data.isSuccess) {
          setMessage(data.data.message);
          setOpenSnackBar(true);
          setOpen(false);
        }
      })
      .catch((error) => {
        console.log("AddPatientReport Error : ", error);
        setMessage("Something went wrong");
        setOpenSnackBar(true);
      });
  };

  const handleViewReport = (PatientUserID) => {
    GetPatientReport(PatientUserID);
  };

  const GetPatientReport = (PatientUserID) => {
    doctorServices
      .GetPatientReport(Number(PatientUserID))
      .then((data) => {
        console.log("GetPatientReport Data : ", data);
        debugger;
        if (data.data.isSuccess) {
          setPatientReportList(data.data.data);
          setOpenReport(true);
        }
        setMessage(data.data.message);
        setOpenSnackBar(true);
      })
      .catch((error) => {
        console.error("GetPatientReport Error : ", error);
        setMessage("Something went wrong");
        setOpenSnackBar(true);
      });
  };

  return (
    <div className="GetProduct-Container">
      <div className="GetProduct-SubContainer">
        <div className="GetProduct-SubContainer1">
          <div className="GetProduct-SubContainer11">
            <TableContainer component={Paper}>
              <Table className="" aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      align="center"
                      style={{ width: 50, fontWeight: 600, fontSize: 15 }}
                    >
                      ID
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 150, fontWeight: 600, fontSize: 15 }}
                    >
                      Patient Name
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Date
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Time
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Status
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 300, fontWeight: 600, fontSize: 15 }}
                    ></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Array.isArray(List) && List.length > 0
                    ? List.map(function (data, index) {
                        return data.status !== "Pending" ? (
                          <>
                            <TableRow key={index}>
                              <TableCell align="center" style={{ width: 50 }}>
                                {data.id}
                              </TableCell>
                              <TableCell align="center" style={{ width: 150 }}>
                                {data.patientName}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.appointmentDate}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.appointmentTime}
                              </TableCell>
                              <TableCell align="center" style={{ width: 100 }}>
                                {data.status}
                              </TableCell>
                              <TableCell align="center" style={{ width: 300 }}>
                                {data.status === "confirm" ? (
                                  <>
                                    <div
                                      className="btn btn-info mx-1"
                                      onClick={() => {
                                        handleAddReport(data);
                                      }}
                                    >
                                      Add Report
                                    </div>
                                    <div
                                      className="btn btn-warning"
                                      onClick={() => {
                                        handleViewReport(data.patientUserID);
                                      }}
                                    >
                                      View Report
                                    </div>
                                  </>
                                ) : null}
                                {data.status !== "confirm" ? (
                                  <div
                                    className="btn btn-success"
                                    onClick={() => {
                                      handleChangeAppointmentStatus(
                                        data,
                                        "confirm"
                                      );
                                    }}
                                  >
                                    Confirm
                                  </div>
                                ) : null}
                                {data.status !== "cancel" ? (
                                  <div
                                    className="btn btn-danger mx-1"
                                    onClick={() => {
                                      handleChangeAppointmentStatus(
                                        data,
                                        "cancel"
                                      );
                                    }}
                                  >
                                    Cancel
                                  </div>
                                ) : null}
                              </TableCell>
                            </TableRow>
                          </>
                        ) : (
                          <></>
                        );
                      })
                    : null}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
      </div>

      <Modal
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={Open}
        // open={true}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={Open}>
          <div
            className="p-5"
            style={{
              backgroundColor: "white",
              boxShadow: "5",
              padding: "2px 4px 3px",
              width: "600px",
              height: "580px",
              display: "flex",
              fontWeight: 500,
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <div className="mb-3 fs-2">Add Report</div>
            <div className="mb-3">User ID :&nbsp;{Data.PatientUserID}</div>
            <div className="mb-3">Doctor ID :&nbsp;{Data.DoctorUserID}</div>
            <div className="form-group mb-5">
              <label>Patient Report</label>
              <textarea
                rows={10}
                className="form-control"
                style={{ width: 450 }}
                onChange={(event) => {
                  setData({ ...Data, ReportDescription: event.target.value });
                }}
              ></textarea>
            </div>
            <div className="w-100 d-flex justify-content-between">
              <div
                className="btn btn-light"
                onClick={() => {
                  setOpen(false);
                }}
              >
                Cancel
              </div>
              <div
                className="btn btn-primary"
                onClick={() => {
                  handleSendReport();
                }}
              >
                Send Report
              </div>
            </div>
          </div>
        </Fade>
      </Modal>

      <Modal
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={OpenReport}
        // open={true}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={OpenReport}>
          <div
            className="p-5"
            style={{
              backgroundColor: "yellow",
              boxShadow: "5",
              padding: "2px 4px 3px",
              width: "1300px",
              height: "580px",
              display: "flex",
              fontWeight: 500,
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <div className="mb-3 fs-2">View Reports</div>
            <TableContainer component={Paper}>
              <Table className="" aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell
                      align="center"
                      style={{ width: 50, fontWeight: 600, fontSize: 15 }}
                    >
                      Report ID
                    </TableCell>
                    <TableCell
                      align="center"
                      style={{ width: 150, fontWeight: 600, fontSize: 15 }}
                    >
                      Doctor Name
                    </TableCell>
                    {/* <TableCell
                      align="center"
                      style={{ width: 100, fontWeight: 600, fontSize: 15 }}
                    >
                      Appointment Date & Time
                    </TableCell> */}
                    <TableCell
                      align="center"
                      style={{ width: 250, fontWeight: 600, fontSize: 15 }}
                    >
                      Report
                    </TableCell>
                    {/* <TableCell
                      align="center"
                      style={{ width: 300, fontWeight: 600, fontSize: 15 }}
                    ></TableCell> */}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Array.isArray(PatientReportList) &&
                  PatientReportList.length > 0
                    ? PatientReportList.map(function (data, index) {
                        return data.status !== "pending" ? (
                          <>
                            <TableRow key={data.id}>
                              <TableCell align="center" style={{ width: 50 }}>
                                {data.id}
                              </TableCell>
                              <TableCell align="center" style={{ width: 200 }}>
                                {data.doctorUserdata.name}
                              </TableCell>
                              <TableCell align="center" style={{ width: 50 }}>
                                {data.report}
                              </TableCell>
                            </TableRow>
                          </>
                        ) : (
                          <></>
                        );
                      })
                    : null}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </Fade>
      </Modal>

      <Backdrop style={{ zIndex: "1", color: "#fff" }} open={OpenLoader}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={OpenSnackBar}
        autoHideDuration={2000}
        onClose={handleSnackBarClose}
        message={Message}
        action={
          <React.Fragment>
            <Button
              color="secondary"
              size="small"
              onClick={handleSnackBarClose}
            >
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleSnackBarClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
}
