import React, { useEffect, useState } from "react";
import "./GetUserHistory.css";

import PatientServices from "../../services/PatientServices";
import DoctorServices from "../../services/DoctorServices";
import Button from "@material-ui/core/Button";
import Pagination from "@material-ui/lab/Pagination";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import RemoveIcon from "@material-ui/icons/Remove";
import AddIcon from "@material-ui/icons/Add";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import PaymentIcon from "@material-ui/icons/Payment";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";

const patientServices = new PatientServices();
const doctorServices = new DoctorServices();

export default function GetUserHistory() {
  const [Message, setMessage] = useState("");
  const [OpenSnackBar, setOpenSnackBar] = useState(false);
  const [List, setList] = useState([]);
  const [OpenLoader, setOpenLoader] = useState(false);
  const [FeedBack, setFeedBack] = useState("");
  const [Open, setOpen] = useState(false);
  const [DoctorUserID, setDoctorUserID] = useState(0);

  useEffect(() => {
    GetPatient();
  }, []);

  const handleSnackBarClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpenSnackBar(false);
  };

  const GetPatient = () => {
    let data = {
      patientID: Number(localStorage.getItem("PATIENT_USERID")),
    };
    patientServices
      .GetPatient(data)
      .then((data) => {
        console.log("GetPatient Data : ", data);
        if (data.data.isSuccess) {
          setList(data.data.data);
        }
      })
      .catch((error) => {
        console.log("GetPatient Error : ", error);
      });
  };

  const handleChangeAppointmentStatus = (_data) => {
    let data = {
      id: _data.id,
      status: "cancel",
    };
    doctorServices
      .ChangePatientStatus(data)
      .then((data) => {
        console.log("ChangePatientStatus Data : ", data);
        if (data.data.isSuccess) {
          setMessage(data.data.message);
          setOpenSnackBar(true);
          GetPatient();
        }
      })
      .catch((error) => {
        console.error("ChangePatientStatus Error : ", error);
        setMessage("Something went Wrong");
        setOpenSnackBar(true);
      });
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleFeedOpen = (doctorUserID) => {
    setOpen(true);
    setDoctorUserID(doctorUserID);
  };

  const handleSendFeedBack = () => {
    debugger;
    if (FeedBack === "") {
      setMessage("Please Enter Feedback");
      setOpenSnackBar(true);
      return;
    }

    let _data = {
      patientUserID: Number(localStorage.getItem("PATIENT_USERID")),
      doctorUserID: Number(DoctorUserID),
      feedback: FeedBack,
    };

    patientServices
      .SendFeedback(_data)
      .then((data) => {
        console.log("SendFeedback Data : ", data);
        setMessage(data.data.message);
        setOpenSnackBar(true);
        setOpen(false);
      })
      .catch((error) => {
        console.log("SendFeedback Error : ", error);
        setMessage("Something went wrong");
        setOpenSnackBar(true);
      });
  };

  return (
    <div className="GetUserHistory-Container p-1">
      <TableContainer component={Paper}>
        <Table className="" aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell
                align="center"
                style={{ width: 50, fontWeight: 600, fontSize: 15 }}
              >
                ID
              </TableCell>
              <TableCell
                align="center"
                style={{ width: 200, fontWeight: 600, fontSize: 15 }}
              >
                Doctor Name
              </TableCell>
              <TableCell
                align="center"
                style={{ width: 100, fontWeight: 600, fontSize: 15 }}
              >
                Specialization
              </TableCell>
              <TableCell
                align="center"
                style={{ width: 100, fontWeight: 600, fontSize: 15 }}
              >
                Status
              </TableCell>
              <TableCell
                align="center"
                style={{ width: 210, fontWeight: 600, fontSize: 15 }}
              ></TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {Array.isArray(List) && List.length > 0
              ? List.map(function (data, index) {
                  return (
                    <TableRow key={index}>
                      <>
                        <TableCell align="center" style={{ width: 200 }}>
                          {data.id}
                        </TableCell>
                        <TableCell align="center" style={{ width: 200 }}>
                          {data.doctorName}
                        </TableCell>
                        <TableCell align="center" style={{ width: 100 }}>
                          {data.doctorSpecialization}
                        </TableCell>
                        <TableCell align="center" style={{ width: 100 }}>
                          {data.status}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{
                            width: 210,
                          }}
                        >
                          <div
                            className="btn btn-info mx-1"
                            onClick={() => {
                              handleFeedOpen(data.doctorUserID);
                            }}
                          >
                            Feedback
                          </div>
                          {data.status !== "cancel" ? (
                            <div
                              className="btn btn-danger"
                              onClick={() => {
                                handleChangeAppointmentStatus(data);
                              }}
                            >
                              Cancel Appointment
                            </div>
                          ) : null}
                        </TableCell>
                      </>
                    </TableRow>
                  );
                })
              : null}
          </TableBody>
        </Table>
      </TableContainer>

      <Modal
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        open={Open}
        // open={true}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={Open}>
          <div
            className="p-5"
            style={{
              backgroundColor: "white",
              boxShadow: "5",
              padding: "2px 4px 3px",
              width: "600px",
              height: "580px",
              display: "flex",
              fontWeight: 500,
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <div className="form-group mb-5">
              <label>Feedback</label>
              <textarea
                rows={10}
                className="form-control"
                style={{ width: 450 }}
                onChange={(event) => {
                  setFeedBack(event.target.value);
                }}
              ></textarea>
            </div>
            <div className="w-100 d-flex justify-content-between">
              <div
                className="btn btn-light"
                onClick={() => {
                  handleClose();
                }}
              >
                Cancel
              </div>
              <div
                className="btn btn-primary"
                onClick={() => {
                  handleSendFeedBack();
                }}
              >
                Send Feedback
              </div>
            </div>
          </div>
        </Fade>
      </Modal>

      <Backdrop style={{ zIndex: "1", color: "#fff" }} open={OpenLoader}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={OpenSnackBar}
        autoHideDuration={2000}
        onClose={handleSnackBarClose}
        message={Message}
        action={
          <React.Fragment>
            <Button
              color="secondary"
              size="small"
              onClick={handleSnackBarClose}
            >
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleSnackBarClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
}
