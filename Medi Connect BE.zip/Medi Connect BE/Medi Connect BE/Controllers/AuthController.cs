﻿using Medi_Connect_BE.Data;
using Medi_Connect_BE.DataAccessLayer;
using Medi_Connect_BE.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Medi_Connect_BE.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthDL _authDL;
        private readonly IConfiguration _configuration;
        public AuthController(IAuthDL authDL, IConfiguration configuration)
        {
            _authDL = authDL;
            _configuration = configuration;
        }

        [HttpPost]
        public async Task<IActionResult> Registration(RegistrationRequest request)
        {
            BasicResponse response = new BasicResponse();
            try {
                response = await _authDL.Registration(request); 
            }
            catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> LogIn(LogInRequest request)
        {
            LogInResponse response = new LogInResponse();
            try
            {
                response = await _authDL.LogIn(request);
                if(response.IsSuccess)
                {
                    response.Token = CreateToken(response.data, "Authentication Token");
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        private string CreateToken(UserDetails request, string Type)
        {
            try
            {
                var symmetricSecuritykey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                var signingCreds = new SigningCredentials(symmetricSecuritykey, SecurityAlgorithms.HmacSha256);

                var claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.Role, request.Role));
                claims.Add(new Claim("UserName", request.Name.ToString()));
                claims.Add(new Claim("UserId", request.Id.ToString()));
                claims.Add(new Claim("TokenType", Type));

                var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
                    _configuration["Jwt:Audiance"],
                    claims,
                    expires: DateTime.Now.AddHours(1),
                    signingCredentials: signingCreds);
                return new JwtSecurityTokenHandler().WriteToken(token).ToString();

            }
            catch (Exception ex)
            {
                return ex.Message;
            }            
        }

    }
}
