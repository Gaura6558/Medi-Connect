﻿using Medi_Connect_BE.DataAccessLayer;
using Medi_Connect_BE.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Medi_Connect_BE.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly IDoctorDL _doctorDL;
        public DoctorController(IDoctorDL doctorDL) 
        {
            _doctorDL = doctorDL;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPatientList(int DoctorUserID)
        {
            GetAllPatientListResponse response = new GetAllPatientListResponse();
            try
            {
                response = await _doctorDL.GetAllPatientList(DoctorUserID);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpPatch]
        public async Task<IActionResult> ChangePatientStatus(ChangePatientStatusRequest request)
        {
            BasicResponse response = new BasicResponse();
            try
            {
                response = await _doctorDL.ChangePatientStatus(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> AddPatientReport(AddPatientReportRequest request)
        {
            BasicResponse response = new BasicResponse();
            try
            {
                response = await _doctorDL.AddPatientReport(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpGet]
        public async Task<IActionResult> GetPatientReport([FromQuery] int PatientUserID)
        {
            GetPatientReportResponse response = new GetPatientReportResponse();
            try
            {
                response = await _doctorDL.GetPatientReport(PatientUserID);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpGet]
        public async Task<IActionResult> GetFeedback([FromQuery] int DoctorUserID)
        {
            GetFeedbackResponse response = new GetFeedbackResponse();
            try
            {
                response = await _doctorDL.GetFeedback(DoctorUserID);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteFeedback([FromQuery] int FeedbackID)
        {
            BasicResponse response = new BasicResponse();
            try
            {
                response = await _doctorDL.DeleteFeedback(FeedbackID);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return Ok(response);
        }

    }
}
