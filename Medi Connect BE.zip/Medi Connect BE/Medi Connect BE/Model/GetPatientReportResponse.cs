﻿using Medi_Connect_BE.Data;

namespace Medi_Connect_BE.Model
{
    public class GetPatientReportResponse
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public List<GetPatientReport>? data { get; set; }
    }

    public class GetPatientReport
    {
        public int Id { get; set; }
        public string? InsertionDate { get; set; }
        public UserDetails? PatientUserdata { get; set; }
        public UserDetails? DoctorUserdata { get; set; }
        public string? Report { get; set; }
    }
    
}
