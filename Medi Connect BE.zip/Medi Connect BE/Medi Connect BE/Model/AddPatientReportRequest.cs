﻿namespace Medi_Connect_BE.Model
{
    public class AddPatientReportRequest
    {
        public int PatientUserID { get; set; }
        public int DoctorUserID { get; set; }
        public string? Report { get; set; }
    }
}
