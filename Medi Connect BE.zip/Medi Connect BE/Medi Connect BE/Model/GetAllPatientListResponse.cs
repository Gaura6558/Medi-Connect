﻿using Medi_Connect_BE.Data;

namespace Medi_Connect_BE.Model
{
    public class GetAllPatientListResponse
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public List<PatientDetails>? data { get; set; }
    }

}
