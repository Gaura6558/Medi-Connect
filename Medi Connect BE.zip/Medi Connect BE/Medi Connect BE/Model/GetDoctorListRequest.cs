﻿using Medi_Connect_BE.Data;

namespace Medi_Connect_BE.Model
{
    public class GetDoctorListRequest
    {
        public string? City { get; set; }
        public string? Specification { get; set; }
    }

    public class GetDoctorListResponse
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public List<UserDetails>? data { get; set; }
    }
}
