﻿using Medi_Connect_BE.Data;

namespace Medi_Connect_BE.Model
{
    public class SendFeedbackRequest
    {
        public int PatientUserID { get; set; }
        public int DoctorUserID { get; set; }
        public string? Feedback { get; set; }
    }

    public class GetFeedbackResponse
    {

        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public List<GetFeedback>? data { get; set; }

    }

    public class GetFeedback
    {
        public int Id { get; set; }
        public string? InsertionDate { get; set; }
        public UserDetails? PatientUserDetails { get; set; }
        public UserDetails? DoctorUserDetails { get; set; }
        public string? Feedback { get; set; }
    }
}
