﻿namespace Medi_Connect_BE.Model
{
    public class ChangePatientStatusRequest
    {
        public int ID { get; set; }
        public string? Status { get; set; }
    }
}
