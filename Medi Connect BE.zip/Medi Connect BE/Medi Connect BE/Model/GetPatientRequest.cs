﻿namespace Medi_Connect_BE.Model
{
    public class GetPatientRequest
    {
        public int PatientID { get; set; }
    }
}
