﻿using Medi_Connect_BE.Data;
using Microsoft.EntityFrameworkCore;

namespace E_Commerce_web_api.Data
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions options) : base(options) {}

        public DbSet<UserDetails>? UserDetails { get; set;}

        public DbSet<PatientDetails> PatientDetails { get; set; }

        public DbSet<PatientReport> PatientReport { get; set; }
        
        public DbSet<FeedbackDetails> FeedbackDetails { get; set; }
    }
}
