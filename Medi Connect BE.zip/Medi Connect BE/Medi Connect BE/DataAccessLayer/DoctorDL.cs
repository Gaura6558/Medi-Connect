﻿using E_Commerce_web_api.Data;
using Medi_Connect_BE.Data;
using Medi_Connect_BE.Model;
using Microsoft.EntityFrameworkCore;

namespace Medi_Connect_BE.DataAccessLayer
{
    public class DoctorDL : IDoctorDL
    {
        private readonly ApplicationDBContext _dBContext;
        public DoctorDL(ApplicationDBContext dBContext)
        {
            _dBContext = dBContext;
        }

        public async Task<BasicResponse> AddPatientReport(AddPatientReportRequest request)
        {
            BasicResponse response = new BasicResponse();
            response.IsSuccess = true;
            response.Message = "Add Patient Successful";

            try
            {
                PatientReport _data = new PatientReport();
                _data.InsertionDate = DateTime.Now.ToString("dd-MM-yyyy");
                _data.DoctorUserID = request.DoctorUserID;
                _data.PatientUserID = request.PatientUserID;
                _data.Report = request.Report;
                await _dBContext.AddAsync(_data);
                await _dBContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<BasicResponse> ChangePatientStatus(ChangePatientStatusRequest request)
        {
            BasicResponse response = new BasicResponse();
            response.IsSuccess = true;
            response.Message = "Change Status Successfully";
            try
            {

                var _patientData = (from _data in _dBContext.PatientDetails
                                    where _data.Id == request.ID
                                    select _data).FirstOrDefault();

                if (_patientData == null)
                {
                    response.IsSuccess = false;
                    response.Message = "Wrong Patient ID";
                    return response;
                }

                _patientData.Status = request.Status;
                await _dBContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<BasicResponse> DeleteFeedback(int FeedbackID)
        {
            BasicResponse response = new BasicResponse();
            response.IsSuccess = true;
            response.Message = "Delete Feedback Successfully";
            try {
                var IsFeedbackDelete = _dBContext.FeedbackDetails.FirstOrDefault(x=>x.Id == FeedbackID);
                if(IsFeedbackDelete == null)
                {
                    response.IsSuccess = false;
                    response.Message = "Feedback Already Deleted";
                    return response;
                }

                _dBContext.FeedbackDetails.Remove(IsFeedbackDelete);
                _dBContext.SaveChangesAsync().Wait();
            }
            catch(Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<GetAllPatientListResponse> GetAllPatientList(int DoctorUserID)
        {
            GetAllPatientListResponse response = new GetAllPatientListResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                response.data = new List<PatientDetails>();
                response.data = (from _data in _dBContext.PatientDetails
                                 where _data.DoctorUserID == DoctorUserID
                                 select _data).ToList();

                if (response.data.Count == 0)
                {
                    response.IsSuccess = false;
                    response.Message = "Record Not Found";
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<GetFeedbackResponse> GetFeedback(int DoctorUserID)
        {
            GetFeedbackResponse response = new GetFeedbackResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {

                response.data = new List<GetFeedback>();    
                var _data = _dBContext.FeedbackDetails.Where(x=>x.DoctorUserID==DoctorUserID).ToList(); 
                if(_data.Count == 0)
                {
                    response.IsSuccess = true;
                    response.Message = "Feedback Not Found";
                }
                _data.ForEach(x =>
                {
                    GetFeedback _getData = new GetFeedback();
                    _getData.Id = x.Id;
                    _getData.InsertionDate = x.InsertionDate;
                    _getData.Feedback = x.Feedback;
                    _getData.DoctorUserDetails = new UserDetails();
                    _getData.DoctorUserDetails =  _dBContext.UserDetails?.FirstOrDefault(x1 => x1.Id == x.DoctorUserID);
                    _getData.DoctorUserDetails.Password = string.Empty;
                    _getData.PatientUserDetails = new UserDetails();
                    _getData.PatientUserDetails = _dBContext.UserDetails?.FirstOrDefault(x1=>x1.Id == x.PatientUserID);
                    _getData.PatientUserDetails.Password = string.Empty;
                    response.data.Add(_getData);
                });
            }catch (Exception ex)
            {
                response.IsSuccess=false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<GetPatientReportResponse> GetPatientReport(int PatientUserID)
        {

            GetPatientReportResponse response = new GetPatientReportResponse();
            response.IsSuccess = true;
            response.Message = "Get Report Successful";
            try
            {

                var _data = (from data in _dBContext.PatientReport
                             where data.PatientUserID == PatientUserID
                             select data).ToList();

                if (_data.Count == 0)
                {
                    response.IsSuccess = false;
                    response.Message = "Patient Report Not Found";
                    return response;
                }

                response.data = new List<GetPatientReport>();

                foreach (var _pData in _data)
                {
                    GetPatientReport getData = new GetPatientReport();
                    getData.Id = _pData.Id;
                    getData.InsertionDate = _pData.InsertionDate;
                    getData.Report = _pData.Report;
                    getData.PatientUserdata = new UserDetails();
                    getData.PatientUserdata = await _dBContext
                                                    .UserDetails?
                                                    .FirstOrDefaultAsync(x => x.Id == _pData.PatientUserID);
                    getData.PatientUserdata.Password = string.Empty;
                    getData.DoctorUserdata = new UserDetails();
                    getData.DoctorUserdata = await _dBContext
                                                    .UserDetails?
                                                    .FirstOrDefaultAsync(x => x.Id == _pData.DoctorUserID);
                    getData.DoctorUserdata.Password = string.Empty;
                    response.data.Add(getData);
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return response;
        }
    }
}
