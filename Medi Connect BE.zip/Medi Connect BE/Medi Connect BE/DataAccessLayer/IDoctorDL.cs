﻿using Medi_Connect_BE.Model;

namespace Medi_Connect_BE.DataAccessLayer
{
    public interface IDoctorDL
    {
        Task<GetAllPatientListResponse> GetAllPatientList(int DoctorUserID);
        Task<BasicResponse> ChangePatientStatus(ChangePatientStatusRequest request);
        Task<GetPatientReportResponse> GetPatientReport(int PatientUserID);
        Task<BasicResponse> AddPatientReport(AddPatientReportRequest request);
        Task<GetFeedbackResponse> GetFeedback(int DoctorUserID);
        Task<BasicResponse> DeleteFeedback(int FeedbackID);
    }
}
