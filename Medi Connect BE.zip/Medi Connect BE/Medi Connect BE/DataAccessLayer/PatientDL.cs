﻿using E_Commerce_web_api.Data;
using Medi_Connect_BE.Data;
using Medi_Connect_BE.Model;
using Microsoft.EntityFrameworkCore;

namespace Medi_Connect_BE.DataAccessLayer
{
    public class PatientDL : IPatientDL
    {
        private readonly ApplicationDBContext _dBContext;
        public PatientDL(ApplicationDBContext dBContext)
        {
            _dBContext = dBContext;
        }

        public async Task<BasicResponse> AddPatient(AddPatientRequest request)
        {
            BasicResponse response = new BasicResponse();
            response.IsSuccess = true;
            response.Message = "Add Patient Successfully";

            try
            {
                PatientDetails _data = new PatientDetails()
                {
                    InsertionDate = DateTime.Now.ToString("dd-MM-yyyy"),
                    DoctorUserID = request.DoctorUserID,
                    PatientUserID = request.PatientUserID,
                    PatientName = request.PatientName,
                    PatientCity = request.PatientCity,
                    Description = request.Description,
                    AppointmentDate = request.AppointmentDate,
                    AppointmentTime = request.AppointmentTime,
                    Status = "Pending"
                };

                await _dBContext.AddAsync(_data);
                await _dBContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return response;
        }

        public async Task<GetAllCityAndSpecializationListResponse> GetAllCityAndSpecializationList()
        {
            GetAllCityAndSpecializationListResponse response = new GetAllCityAndSpecializationListResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            response.city = new List<string>();
            response.specialization = new List<string>();
            try
            {

                response.city = (from _data in _dBContext.UserDetails
                                 where _data.Role.ToLower() == "doctor" && !String.IsNullOrEmpty(_data.City)
                                 select _data.City.Trim()).Distinct().ToList();

                response.specialization = (from _data in _dBContext.UserDetails
                                           where _data.Role.ToLower() == "doctor" && !String.IsNullOrEmpty(_data.City)
                                           select _data.Specialization.Trim()).Distinct().ToList();

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<GetDoctorListResponse> GetDoctorList(GetDoctorListRequest request)
        {
            GetDoctorListResponse response = new GetDoctorListResponse();
            response.IsSuccess = true;
            response.Message = "Successfully";
            try
            {
                response.data = new List<UserDetails>();
                if (String.IsNullOrEmpty(request.City) && String.IsNullOrEmpty(request.Specification))
                {
                    response.data = _dBContext.UserDetails?.Where(x => x.Role.ToLower() == "doctor").ToList();
                }
                else if (!String.IsNullOrEmpty(request.City) && !String.IsNullOrEmpty(request.Specification))
                {
                    response.data = _dBContext
                        .UserDetails?
                        .Where(x => x.Role.ToLower() == "doctor" && x.City.ToLower() == request.City.ToLower() &&
                        x.Specialization.ToLower() == request.Specification.ToLower()).ToList();
                }
                else if (!String.IsNullOrEmpty(request.Specification) && String.IsNullOrEmpty(request.City))
                {
                    response.data = _dBContext
                        .UserDetails?
                        .Where(x => x.Role.ToLower() == "doctor" && x.Specialization.ToLower() == request.Specification.ToLower()).ToList();
                }
                else if (!String.IsNullOrEmpty(request.City) && String.IsNullOrEmpty(request.Specification))
                {
                    response.data = _dBContext
                        .UserDetails?
                        .Where(x => x.Role.ToLower() == "doctor" && x.City.ToLower() == request.City.ToLower()).ToList();
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<GetPatientResponse> GetPatient(GetPatientRequest request)
        {
            GetPatientResponse response = new GetPatientResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {

                var _patientDataList = (from _data in _dBContext.PatientDetails
                                        where _data.PatientUserID == request.PatientID
                                        select _data)
                                 .ToList();

                if (_patientDataList.Count == 0)
                {
                    response.IsSuccess = false;
                    response.Message = "Patient Record Not Found";
                    return response;
                }

                response.data = new List<GetPatient>();
                _patientDataList.ForEach(async x =>
                        {
                            GetPatient _data = new GetPatient();
                            _data.Id = x.Id;
                            _data.InsertionDate = x.InsertionDate;
                            _data.PatientUserID = x.PatientUserID;
                            var _doctorData = _dBContext.UserDetails?.FirstOrDefault(x1 => x1.Id == x.DoctorUserID);
                            _data.DoctorUserID = x.DoctorUserID;
                            _data.DoctorName = _doctorData?.Name;
                            _data.DoctorCity = _doctorData?.City;
                            _data.DoctorSpecialization = _doctorData?.Specialization;
                            _data.PatientName = _doctorData?.Name;
                            _data.PatientCity = _doctorData?.City;
                            _data.Description = x.Description;
                            _data.AppointmentDate = x.AppointmentDate;
                            _data.AppointmentTime = x.AppointmentTime;
                            _data.Status = x.Status;
                            response.data?.Add(_data);

                        });

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Message : " + ex.Message;
            }

            return response;
        }

        public async Task<BasicResponse> SendFeedback(SendFeedbackRequest request)
        {
            BasicResponse response = new BasicResponse();
            response.IsSuccess = true;
            response.Message = "Send Feedback Successfully";

            try
            {
                FeedbackDetails details = new FeedbackDetails();
                details.InsertionDate = DateTime.Now.ToString("dd-MM-yyyy");
                details.PatientUserID = request.PatientUserID;
                details.DoctorUserID = request.DoctorUserID;
                details.Feedback = request.Feedback;
                await _dBContext.AddAsync(details);
                await _dBContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}
